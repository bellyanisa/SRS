<?php
    $servername = "localhost";
    $username = "se62_13";
    $password = "se62_13";
    $dbname = "se62_13";

    // $servername = "localhost";
    // $username = "root";
    // $password = "";
    // $dbname = "se62_13";

    $conn = new mysqli($servername, $username, $password, $dbname); 
    $conn->set_charset('utf8');
        if($conn->connect_error)
        {
            die("Connection failed: ".$conn->connect_error);
        }
        if(!$conn->select_db($dbname))
        {
            die("Connection failed: ".$conn->connect_error);
        }
    
    // try {
        
    //     $conn = new PDO("mysql:host=$servername;port=5738;dbname=$dbname", $username, $password); 
    //     // set the PDO error mode to exception
    //     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //     echo "Connected successfully";

    //     }
    // catch(PDOException $e)
    //     {
    //     echo "Connection failed: " . $e->getMessage();
    //     }
 




?>




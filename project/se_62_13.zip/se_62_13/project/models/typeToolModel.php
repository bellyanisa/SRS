<?php 
    class typeTool
    {
        public $id_type,$type_name;
        public function __construct($id_type,$type_name) 
        {
            $this->id_type = $id_type;
            $this->type_name = $type_name;
            
        }
        public static function get($id_type)
        {
            require("connection_connect.php");
            $sql = "SELECT * FROM `type_tool`";
            $result=$conn->query($sql);
            while($my_row = $result -> fetch_assoc())
            {
                if($id_type==$my_row['id_type']){
                    break;
                }
                    
            }               
            $id_type= $my_row['id_type'];		
            $type_name = $my_row['typeTool_name'];
            require("connection_close.php");
 
            return new typeTool($id_type,$type_name);
        }
        public static function getAll()
        {
            $toolList = [];
            require("connection_connect.php");
            $sql = "SELECT * FROM `type_tool` WHERE 1";
            $result = $conn->query($sql);
            
            while ($my_row = $result->fetch_assoc()) 
            {
                $id_type = $my_row['id_type']; //ตัวแปรสีส้มคือในdb
                $type_name= $my_row['typeTool_name'];	
                $typeList[] = new typeTool($id_type,$type_name);
            }
            require("connection_close.php");
            return $typeList;
        }
        public static function add($type_name)
        {
            require("connection_connect.php");
            $sql = "INSERT into type_tool (typeTool_name) 
            values ('$type_name')";
            $result= $conn->query($sql); 
            require("connection_close.php");
            return "add success $result rows"; 
        }
        public static function delete($id_type)
        {   
            require_once("connection_connect.php");
            $sql = "DELETE from type_tool Where id_type = '$id_type'";
            $result= $conn->query($sql);
            require("connection_close.php");
            return "delete success $result row";     
        }
        public static function update($id_type,$type_name)
        {   
            require("connection_connect.php");
            $sql = "UPDATE type_tool SET typeTool_name = '$type_name'
            WHERE id_type = '$id_type' ";
            $result= $conn->query($sql);
            require("connection_close.php");
            return "update success $result row";     
        }
    
    }
?>
<?php 
    class Borrow
    {
        public $tool_name,$username,$id_teacher,$status_borrow;
        public function __construct($tool_name,$username,$id_teacher,$status_borrow) 
        {
            $this->tool_name = $tool_name;
            $this->username = $username;
            $this->id_teacher = $id_teacher;
            $this->status_borrow = $status_borrow;
            
        }
       
        public static function add($tool_name,$username,$id_teacher,$status_borrow)
        {
            require("connection_connect.php");
            $sql = "INSERT into tool (id_user,serial_num,id_teacher,status_borrow) 
            values ('$username','$tool_name','$id_teacher','$status_borrow')";
            $result= $conn->query($sql); 
            require("connection_close.php");
            return "add success $result rows"; 
        }
    
    }
?>
<?php
    class PagesController
    {	

        public function home()
        {	
            $toolList = Tool::getAll();
            require_once("view/pages/home.php");	
        }
        public function homeStaff()
        {	
            $toolList = Tool::search("");
            require_once("view/pages/homeStaff.php");	
        }
        public function homeStudent()
        {	
            $toolList = Tool::search("");
            require_once("view/pages/homeStudent.php");	
        }
        public function homeTeacher()
        {	
            $toolList = Tool::search("");
            require_once("view/pages/homeTeacher.php");	
        }
	    public function error()
	    {	
            require_once("view/pages/error.php");	
        }
        public function index1()
	    {	
            $toolList = Tool::getAll();
		    require_once('view/pages/homeStaff.php');
        }
        public function index2()
	    {	
            $toolList = Tool::getAll();
		    require_once('view/pages/homeStudent.php');
        }
        public function index3()
	    {	
            $toolList = Tool::getAll();
		    require_once('view/pages/homeTeacher.php');
        }
      
    }
?>
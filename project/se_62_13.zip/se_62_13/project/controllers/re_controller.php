<?php
    class reController
    {	
        public function index()
		{	
    
        }
	
    }
?>
<?php   
    class userController
    {	
        public function index()
	    {	
            $userList = User::getAll();
		    require_once('view/user/index.php');
        }
        public function newUser()
		{
			$userList = User::getAll();
			require_once('view/user/newUser.php');
		}	
        public function addUser()
   		{
            $id_user = $_GET['id_user'];
			$pass = $_GET['keypass'];
            $uname = $_GET['username'];
            $type_user = $_GET['type_user'];
            $email = $_GET['email'];
	    	User::Add($id_user,$pass,$uname,$type_user,$email); //add		
	    	UserController::index(); // call student->index
		}
		public function deleteConfirm()
		{
			$id_user = $_GET['id_user'];
			$u = User::get($id_user);
			require_once('view/user/deleteConfirm.php');
		}
		public function delete()
		{
			$id_user = $_GET['id_user'];
			echo"$id_user";
			User::delete($id_user);  // delete student
			UserController::index();  // call student->index
		}
		public function updateForm()
		{	
        	$id_user = $_GET['id_user'];		
			$u = User::get($id_user);
			require_once('view/user/updateForm.php');
		}
		public function update()
		{
			$id_user = $_GET['id_user'];
			$keypass = $_GET['keypass'];
			$username = $_GET['username'];
			$type_user = $_GET['type_user'];
			$email = $_GET['email'];		
			User::update($id_user,$keypass,$username,$type_user,$email);
			UserController::index();
		}


    } 
?>
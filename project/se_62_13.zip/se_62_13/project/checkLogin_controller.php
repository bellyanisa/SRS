<html>
<?php
session_start();
$serverName = "localhost";
$userName = "se62_13";
$userPassword = "se62_13";
$dbName = "se62_13";

// $serverName = "localhost";
// $userName = "root";
// $userPassword = "";
// $dbName = "se62_13";
$objCon = mysqli_connect($serverName,$userName,$userPassword,$dbName);
mysqli_set_charset($objCon,'utf8');
//echo $_POST['txtUsername']; 

$strSQL = "SELECT * FROM user WHERE id_user = '".mysqli_real_escape_string($objCon,$_POST['txtUsername'])."' 
and password = '".mysqli_real_escape_string($objCon,$_POST['txtPassword'])."'";
//$strSQL = "SELECT * FROM user WHERE id_user = '".$_POST['txtUsername']."' 
//and password = '".$_POST['txtPassword']."'";
//echo $strSQL; 
$objQuery = mysqli_query($objCon,$strSQL);
$row = mysqli_num_rows($objQuery);
$objResult = mysqli_fetch_array($objQuery,MYSQLI_ASSOC);

//print_r($row); die;

if(!$objResult)
{
        echo "Username and Password Incorrect!";
}
else
{
        $_SESSION["UserID"] = $objResult["UserID"];
        $_SESSION["Status"] = $objResult["Status"];

        session_write_close();
        
        if($objResult["type_user"] == "นิสิต")
        {   

            header("location:../view/pages/homeStudent.php");  
        }
        else if($objResult["type_user"] == "อาจารย์")
        {
            header("location:../view/pages/homeTeacher.php");  
        }
        else
        {
            //header("location:../controller/pages_controller.php");  
            header("location:../routes.php?controller=pages&action=homeStaff");  
        }
}
mysqli_close($objCon);
?>
</html>
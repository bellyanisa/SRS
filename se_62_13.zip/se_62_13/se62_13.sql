-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2020 at 12:15 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_13`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrow_tool`
--

CREATE TABLE `borrow_tool` (
  `id_borrow` int(5) NOT NULL,
  `id_user` varchar(20) NOT NULL,
  `serial_num` varchar(20) NOT NULL,
  `id_teacher` int(5) NOT NULL,
  `status_borrow` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrow_tool`
--

INSERT INTO `borrow_tool` (`id_borrow`, `id_user`, `serial_num`, `id_teacher`, `status_borrow`) VALUES
(1, 'b6020551784', '0001-1234-1113', 1, 'รออนุมัติ'),
(2, 'b6020551890', '0001-1234-1119', 5, 'อนุมัติ');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id_employ` int(5) NOT NULL,
  `employ_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id_student` int(10) NOT NULL,
  `student_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id_teacher` int(5) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `email_teacher` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id_teacher`, `teacher_name`, `email_teacher`) VALUES
(1, 'อ.ดร.พิเชษฐ์  สืบสายพรหม', 'pichet.s@ku.ac.th'),
(2, 'อ.ดร.เสกสรรค์  มธุลาภรังสรรค์', 'seksan.m@ku.ac.th'),
(3, 'อ.ดร.กายรัฐ  เจริญราษฎร์', 'kairat.j@ku.ac.th'),
(4, 'ผศ.ดร.จักกริช พฤษการ', 'chakkrit.p@ku.ac.th'),
(5, 'ผศ.นุชนาฎ  สัตยากวี', 'nutchanat.s@ku.ac.th '),
(6, 'อ.ดร.บุญรัตน์ เผดิมรอด', 'fengbyr@ku.ac.th');

-- --------------------------------------------------------

--
-- Table structure for table `tool`
--

CREATE TABLE `tool` (
  `serial_num` varchar(20) NOT NULL,
  `tname` varchar(30) NOT NULL,
  `id_type` int(5) NOT NULL,
  `state_tool` varchar(10) NOT NULL,
  `rightcopy` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tool`
--

INSERT INTO `tool` (`serial_num`, `tname`, `id_type`, `state_tool`, `rightcopy`) VALUES
('0001-1234-1113', 'คีย์บอร์ด', 1, 'ว่าง', 'นิสิต'),
('0001-1234-1114', 'ซีพียู', 1, 'ถูกยืม', 'นิสิต'),
('0001-1234-1115', 'ไดโอด', 2, 'ถูกยืม', 'นิสิต'),
('0001-1234-1116', 'ไดโอด', 2, 'ถูกยืม', 'นิสิต'),
('0001-1234-1117', 'ไอซี 555', 2, 'ว่าง', 'อาจารย์'),
('0001-1234-1118', 'ทรานซิเตอร์', 2, 'ถูกยืม', 'นิสิต'),
('0001-1234-1119', 'กุญแจห้อง 8403', 3, 'ว่าง', 'นิสิต'),
('0001-1234-1120', 'ปลั๊กสามตา', 3, 'ถูกยืม', 'นิสิต'),
('0001-1234-1142', 'ปลั๊กสามตา', 3, 'ว่าง', 'นิสิต'),
('1000-1234-1111', 'เคส', 1, 'ว่าง', 'นิสิต'),
('1000-1234-1112', 'คีย์บอร์ด', 1, 'ว่าง', 'นิสิต'),
('1234-5679-1523', 'กุญแจห้อง 8406', 3, 'ว่าง', 'เจ้าหน้าที'),
('1234-5679-1544', 'ไอซี 555', 2, 'ว่าง', 'อาจารย์'),
('1234-5679-1666', 'กุญแจห้อง 8406', 3, 'ว่าง', 'เจ้าหน้าที');

-- --------------------------------------------------------

--
-- Table structure for table `type_tool`
--

CREATE TABLE `type_tool` (
  `id_type` int(5) NOT NULL,
  `typeTool_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `type_tool`
--

INSERT INTO `type_tool` (`id_type`, `typeTool_name`) VALUES
(1, 'อุปกรณ์คอมพิวเตอร์'),
(2, 'อิเล็กทรอนิกส์'),
(3, 'ทั่วไป'),
(4, 'abc'),
(5, 'กขค'),
(10, 'ooo'),
(11, 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` varchar(20) NOT NULL,
  `keypass` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `type_user` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `keypass`, `username`, `type_user`, `email`) VALUES
('admin', 'admin', 'ผศ.นุชนาฎ  สัตยากวี', 'เจ้าหน้าที่', 'xxxx@gmail.com'),
('b6020551784', '123456', 'ญาณิศา นุชนิยม', 'นิสิต', 'bell@gmail.com'),
('b6020551890', '000000', 'พลวัต ชาญชนะโยธิน', 'นิสิต', 'mix@hotmail.com'),
('e45698', '777777', 'ขวัญศรี ใจดี', 'เจ้าหน้าที่', 'kang@hotmail.com'),
('t123456', '555555', 'สมชาย ชาติชาย', 'อาจารย์', 'som@gmail.com'),
('t5555', '123456', 'อ.กายรัฐ', 'อาจารย์', 'ggg@hotmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrow_tool`
--
ALTER TABLE `borrow_tool`
  ADD PRIMARY KEY (`id_borrow`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `serial_num` (`serial_num`),
  ADD KEY `id_teacher` (`id_teacher`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id_teacher`);

--
-- Indexes for table `tool`
--
ALTER TABLE `tool`
  ADD PRIMARY KEY (`serial_num`),
  ADD KEY `id_type` (`id_type`);

--
-- Indexes for table `type_tool`
--
ALTER TABLE `type_tool`
  ADD PRIMARY KEY (`id_type`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrow_tool`
--
ALTER TABLE `borrow_tool`
  MODIFY `id_borrow` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id_teacher` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `type_tool`
--
ALTER TABLE `type_tool`
  MODIFY `id_type` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrow_tool`
--
ALTER TABLE `borrow_tool`
  ADD CONSTRAINT `borrow_tool_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`),
  ADD CONSTRAINT `borrow_tool_ibfk_2` FOREIGN KEY (`serial_num`) REFERENCES `tool` (`serial_num`),
  ADD CONSTRAINT `borrow_tool_ibfk_3` FOREIGN KEY (`id_teacher`) REFERENCES `teacher` (`id_teacher`);

--
-- Constraints for table `tool`
--
ALTER TABLE `tool`
  ADD CONSTRAINT `tool_ibfk_1` FOREIGN KEY (`id_type`) REFERENCES `type_tool` (`id_type`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


<html>
    <head><h2>ระบบยืม-คืนอุปกรณ์ภาควิชาวิศวกรรมคอมพิวเตอร์</h2></head>         
</html>

<html>
    <head><script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<style>
		choose {
  			float: left;
  			width: 25%;
  			height: 300px; /* only for demonstration, should be removed */
  			background: write;
  			padding: 8px;
		}
		buttonadd {
  			float: right;
  			width: 15%;
  			height: 30px; /* only for demonstration, should be removed */
  			background: write;
  			padding: 8px;
		}
	</style>

	<style type="text/css">
        #scroll_demo 
        {
            width:1200px;
            height:273px;
            border:1px solid write;
            overflow:auto;
        }
    </style>
    </head>
	    <body>
	        <choose>
	            <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
	            <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
	            <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
                <br>
                <div class="sidebar-nav">
                <div class="well" style="background-color:#F0FFF0;width:400px;  padding: 8px;">
        		<ul class="nav nav-list"> 
                <li class="nav-header"><font size="4"; color="black">เมนู<br></font></li> 
				<li><a href="?controller=pages&action=index1"><i class="fas fa-home"  style="color:black"></i><font size="2"> หน้าแรก<br></font></a></li>
				<li><a href=?controller=tool&action=search><i class="icon-search"></i><font size="2"> ค้นหาอุปกรณ์<br></font></a></li>
                <li><a href=?controller=homeStaff&action=cancel><i class="icon-remove"></i><font size="2"> ยกเลิกคำขอยืมอุปกรณ์<br></font></a></li>
        		<li><a href=?controller=homeStaff&action=ok><i class="fa fa-check" style='color:black'></i><font size="2"> อนุมัติการยืม<br></font></a></li>
        		<li><a href="?controller=tool&action=index"><i class="icon-edit"></i><font size="2"> จัดการอุปกรณ์<br></font></a></li>
        		<li><a href=?controller=typeTool&action=index><i class="fas fa-tasks" style='color:black'></i><font size="2"> จัดการหมวดหมู่อุปกรณ์<br></font></a></li>
				<li><a href=?controller=user&action=index><i class="fas fa-address-book" style='color:black'></i><font size="2"> จัดการผู้ใช้<br></font></a></li>
				<li><a href=?controller=homeStaff&action=history><i class="far fa-list-alt" style='color:black'></i><font size="2"> แสดงประวัติยืม-คืนอุปกรณ์<br></font></a></li>
				<li><a href=?controller=homeStaff&action=data><i class="fas fa-chart-bar" style='color:black'></i><font size="2"> สถิติการยืมอุปกรณ์<br></font></a></li>
				<li><a href=?controller=homeStaff&action=return><i class="icon-picture"></i><font size="2"> การคืนอุปกรณ์<br></font></a></li>
				<li><a href="logout.php"><i class="fas fa-power-off" style="color:black"></i><font size="2"> ออกจากระบบ<br></font></a></li>
        		</ul>
        	    </div>
                </div>
		    </choose>
			
	    </body>
</html>

<form method="get" action="">
<br>
    <label>ชื่อหมวดหมู่ <input type="stringvssa" name="typeTool_name" 
    value = "<?php echo $type->typeTool_name; ?>"/> </label><br>
    

	<input  type="hidden" name="controller" value="typeTool"/>	
	<button type="submit" name="action" value="index" class="btn btn-danger"> ยกเลิก</button> 
	<button type="submit" name="action" value="update" class="btn btn-success"> บันทึก</button> 

</form>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

</head>
<body>
<br>
<main class="login-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">ยืนยันการลบอุปกรณ์นี้</div>
                    <div class="card-body">
                        <?php echo "เลขครุภัณฑ์: $tool->serial<br> ชื่ออุปกรณ์: $tool->tool_name <br><br>";?>
                        <form method="get" action="">
                        <input  type="hidden" name="controller" value="tool"/>	
                        <input  type="hidden" name="serial_num" value="<?php echo $tool->serial; ?>"/>
                        <button type="submit" name="action" value="index"> ยกเลิก</button> 
                        <button type="submit" name="action" value="delete"> ยันยืน </button> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>


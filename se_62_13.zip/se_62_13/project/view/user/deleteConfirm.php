
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

</head>
<body>

<main class="login-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">ยืนยันการลบผู้ใช้นี้</div>
                    <div class="card-body">
                        <?php echo "ไอดี: $u->id_user <br>ชื่อผู้ใช้: $u->uname<br> สิทธิ์: $u->type_user <br><br>";?>
                        <form method="get" action="">
                        <input  type="hidden" name="controller" value="user"/>	
                        <input  type="hidden" name="id_user" value="<?php echo $u->id_user; ?>"/>
                        <button type="submit" name="action" value="index"> ยกเลิก</button> 
                        <button type="submit" name="action" value="delete"> ยันยืน </button> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
    if(isset($_GET['controller'])&&isset($_GET['action']))
    {
        $controller = $_GET['controller'];
        $action = $_GET['action'];
    }
    else {
        $controller ='pages';
        $action = 'home';
    }
?>

 <html>
    <head><h2>ระบบยืม-คืนอุปกรณ์ภาควิชาวิศวกรรมคอมพิวเตอร์</h2></head>         
</html>

<html>
    <head><script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<style>
		choose {
  			float: left;
  			width: 25%;
  			height: 300px; /* only for demonstration, should be removed */
  			background: write;
  			padding: 8px;
		}
		buttonadd {
  			float: right;
  			width: 25%;
  			height: 30px; /* only for demonstration, should be removed */
  			background: write;
  			padding: 8px;
		}
	</style>

	<style type="text/css">
        #scroll_demo 
        {
            width:1200px;
            height:273px;
            border:1px solid write;
            overflow:auto;
        }
    </style>
    </head>
	    <body>
	        <choose>
	            <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
	            <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
	            <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
                <br>
                <div class="sidebar-nav">
                <div class="well" style="background-color:#F0FFF0;width:400px;  padding: 8px;">
        		<ul class="nav nav-list"> 
                <li class="nav-header"><font size="4"; color="black">เมนู<br></font></li> 
				<li><a href="?controller=pages&action=index2"><i class="fas fa-home"  style="color:black"></i><font size="2"> หน้าแรก<br></font></a></li>
				<li><a href=?controller=tool&action=searchStudent&key=><i class="icon-search"></i><font size="2"> ค้นหาอุปกรณ์<br></font></a></li>
				<li><a href=?controller=homeStaff&action=cancel><i class="icon-remove"></i><font size="2"> ยกเลิกคำขอยืมอุปกรณ์<br></font></a></li>
				<li><a href=?controller=homeStaff&action=mtool><i class="icon-edit"></i><font size="2"> คำร้องขอเพิ่มอุปกรณ์<br></font></a></li>
				<li><a href=?controller=homeStaff&action=history><i class="far fa-list-alt" style='color:black'></i><font size="2"> แสดงประวัติยืม-คืนอุปกรณ์<br></font></a></li>
				<li><a href="logout.php"><i class="fas fa-power-off" style="color:black"></i><font size="2"> ออกจากระบบ<br></font></a></li>
        		</ul>
        	    </div>
                </div>
		    </choose>
	    </body>
</html>

<buttonadd>
<form method="get" action="">
	<input type="text" name="key">
	<input  type="hidden" name="controller" value="tool"/>
	<button type="submit" name="action" value="searchStudent"> Search</button> </buttonadd><br> <br>
	<label>หมวดหมู่  
		<select name="id_type" >
			<?php foreach($typeList as $type){echo "<option value = $type->id_type> $type->type_name </option>";}?>
		</select>&nbsp;<button type="submit" name="action" value="searchStudent2"> Search</button></label><br>
</form>
</buttonadd>

<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="span7">   
    <div class="widget stacked widget-table action-table">
        <div class="widget-header">
		<br><br> <br><h5>รายการอุปกรณ์</h5>
        </div> <!-- /widget-header -->
	<div class="widget-content">
	<div id="scroll_demo"><div>	
	    <table class="table table-striped table-bordered" >
	    <thead>
        <tr>
	        <th>ลำดับ</th>
		    <th>ชื่ออุปกรณ์</th>
		    <th>หมวดหมู่</th>
			<th>สถานะอุปกรณ์</th>
			<th>ยืมอุปกรณ์</th>				
        </tr>
		</thead>
		<tbody>
            <?php 
				$i=1;  
			    foreach($toolList as $tool)
				{
                    echo "<tr> <td align='center'>$i</td>
					<td align='center'>$tool->tool_name</td> 
					<td align='center'>$tool->type_name</td>
					<td align='center'>$tool->state_tool</td>
					<td align='center'><a href=?controller=borrow&action=newBorrow&serial_num=$tool->serial> ยืมอุปกรณ์ </td></tr>";
					$i = $i+1;
				}
				echo "</table>";
			?>  
		</tbody>	
		</table>
	</div>
    </div> <!-- /widget-content -->
	</div> <!-- /widget -->
</div>
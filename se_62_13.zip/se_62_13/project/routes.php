<?php
    $controllers = array('pages'=>['home','homeStaff','error','homeStudent','homeTeacher','index1','index2','index3'],
    'tool'=>['index','search','newTool','addTool','deleteConfirm','delete','updateForm','searchStudent','searchTeacher','searchStudent2','searchTeacher2'],
    'typeTool'=>['index','newType','addtypeTool','deleteConfirm','delete','updateForm','update'],
    'borrow'=>['index','newBorrow','addBorrow'],
    'teacher'=>['index'],
    'user'=>['index','newUser','addUser','deleteConfirm','delete','updateForm','update']);
                      
    if(isset($_GET['controller'])&&isset($_GET['action']))
    {
        $controller = $_GET['controller'];
        $action = $_GET['action'];
    }
    else {
        $controller ='pages';
        $action = 'home';
    }



    function call($controller, $action)
    {
        require_once("controllers/".$controller."_controller.php");
        
        switch($controller)
        {
            case "pages": 
                require_once("models/toolModel.php");
                $controller = new PagesController();
                break;
            case "tool":	
                require_once("models/toolModel.php");
                require_once("models/typeToolModel.php");
                $controller = new ToolController();
                break;
            case "typeTool":	
                require_once("models/typeToolModel.php");
                $controller = new typeToolController();
                break;
            // case "teacher":	
            //     require_once("models/typeToolModel.php");
            //     $controller = new typeToolController();
            //     break;
            case "user":	
                require_once("models/userModel.php");
                $controller = new userController();
                break;
            case "borrow":	
                require_once("models/userModel.php");
                require_once("models/teacherModel.php");
                require_once("models/toolModel.php");
                require_once("models/typeToolModel.php");
                $uname1 =  $_GET['uname1'];
                $controller = new BorrowController();
                break;

        }
        $controller->{$action}();
    }
    
    if(array_key_exists($controller,$controllers))
    {
        
        if(in_array($action,$controllers[$controller]))
        {
            call($controller,$action);
        }
        else
        {
            call('pages','error');
        }
    }
    else
    {
        call('pages','error');  
    }
?>
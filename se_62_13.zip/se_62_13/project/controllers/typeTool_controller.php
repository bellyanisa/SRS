<?php   
    class typeToolController
    {	
        public function index()
	    {	
            $typeList = typeTool::getAll();
		    require_once('view/typeTool/index.php');
        }
        public function newType()
		{
			$typeList = typeTool::getAll();
			require_once('view/typeTool/newtypeTool.php');
		}	
        public function addtypeTool()
   		{
			$type_name = $_GET['typeTool_name'];
	    	typeTool::Add($type_name); //add		
	    	typeToolController::index(); // call student->index
		}
		public function deleteConfirm()
		{
			$id_type = $_GET['id_type'];
			$type = typeTool::get($id_type);
			require_once('view/typeTool/deleteConfirm.php');
		}
		public function delete()
		{
			$id_type = $_GET['id_type'];
			typeTool::delete($id_type);  // delete student
			typeToolController::index();  // call student->index
		}
		public function updateForm()
		{	
        	$id_type = $_GET['id_type'];		
			$type = typeTool::get($id_type);
			require_once('view/typeTool/updateForm.php');
		}
		public function update()
		{
			$type_name = $_GET['typeTool_name'];		
			typeTool::update($type_name);
			typeToolController::index();
		}


    } 
?>
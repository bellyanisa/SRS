<?php
    class BorrowController
    {	

        // public function updateForm()
		// {	
        // 	$serial = $_GET['serial_num'];		
		// 	$tool = Tool::get($serial);
		// 	require_once('view/tool/updateForm.php');
		// }
		public function update()
		{
			$serial = $_GET['serial_num'];
			$tool_name = $_GET['tname'];
			$id_type = $_GET['id_type'];
			$rightcopy = $_GET['rightcopy'];
			$state_tool = $_GET['state_tool'];		
			Tool::update($serial,$tool_name,$id_type,$rightcopy,$state_tool);
			ToolController::index();
        }
        public function newBorrow()
		{	
            $t = Teacher::getAll();
			$serial = $_GET['serial_num'];
			$uname1 =$_GET['uname1'];
			$serial_num =  $_GET['serial_num'];
			$tool = Tool::get($serial);
			require_once('view/borrow/newBorrow.php');
        }
        public function index()
		{	
            $key = "";

			require("connection_connect.php");
            $sql = "SELECT tool.tname,type_tool.typeTool_name,tool.rightcopy,tool.state_tool,tool.id_type FROM tool INNER JOIN type_tool 
            WHERE tool.tname LIKE '%$key%'
            and tool.id_type=type_tool.id_type and tool.rightcopy = 'นิสิต' and tool.state_tool='ว่าง'";
            $result= $conn->query($sql);	
            while ($my_row = $result->fetch_assoc())	
            {	
                $serial= "555";
                $tool_name= $my_row['tname'];	
                $type_name = $my_row['typeTool_name'];
                $state_tool = $my_row['state_tool'];
                $rightcopy = $my_row['rightcopy'];
                $id_type = $my_row['id_type'];
                $toolList[]= new Tool($serial,$tool_name,$type_name,$state_tool,$rightcopy,null,$id_type);	   
			}
			

            require("connection_close.php");

			require_once('view/tool/searchStudent.php');
        }
	// 	public function addBorrow()
	// 	{
	// 		$serial = $_GET['serial_num'];
	// 	 	$tool_name = $_GET['tname'];
	// 	 	$id_teacher = $_GET['id_teacher'];
	// 	 	$rightcopy = $_GET['rightcopy'];
	// 	 	$state_tool = $_GET['state_tool'];
	// 	 	Borrow::Add($serial,$tool_name,$id_teacher,$rightcopy,$state_tool); //add		
	// 	 	BorrowController::index(); // call student->index
	//  }
    }
?>
<?php 
    class User
    {
        public $id_user,$pass,$uname,$type_user,$email;
        public function __construct($id_user,$pass,$uname,$type_user,$email) 
        {
            $this->id_user = $id_user;
            $this->pass = $pass;
            $this->uname = $uname;
            $this->type_user = $type_user;
            $this->email = $email;
            
        }
        public static function get($id_user)
        {
            require("connection_connect.php");
            $sql = "SELECT * FROM `user`";
            $result=$conn->query($sql);
            while($my_row = $result -> fetch_assoc())
            {
                if($id_user==$my_row['id_user']){
                    break;
                }
                    
            }               
            $id_user= $my_row['id_user'];		
            $pass = $my_row['keypass'];
            $uname = $my_row['username'];	
            $type_user= $my_row['type_user'];	
            $email= $my_row['email'];	
            require("connection_close.php");
 
            return new User($id_user,$pass,$uname,$type_user,$email);
        }
        public static function getAll()
        {
            $userList = [];
            require("connection_connect.php");
            $sql = "SELECT * FROM `user` WHERE 1";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) 
            {
                $id_user= $my_row['id_user'];		
                $pass = $my_row['keypass'];
                $uname = $my_row['username'];
                $type_user= $my_row['type_user'];	
                $email= $my_row['email'];		
                $userList[] = new User($id_user,$pass,$uname,$type_user,$email);
            }
            require("connection_close.php");
            return $userList;
        }
        public static function add($id_user,$pass,$uname,$type_user,$email)
        {
            require("connection_connect.php");
            $sql = "INSERT into user (id_user,keypass,username,type_user,email) 
            values ('$id_user','$pass','$uname','$type_user','$email')";
            $result= $conn->query($sql); 
            require("connection_close.php");
            return "add success $result rows"; 
        }
        public static function delete($id_user)
        {   
            
            require_once("connection_connect.php");
            $sql = "DELETE from user Where id_user = '$id_user'";
            $result= $conn->query($sql);
            require("connection_close.php");
            return "delete success $result row";     
        }
        public static function update($id_user)
        {   
            require("connection_connect.php");
            $sql = "UPDATE user SET id_user = '$id_user'
            WHERE id_user = '$id_user' ";
            $result= $conn->query($sql);
            require("connection_close.php");
            return "update success $result row";     
        }
    
    }
?>
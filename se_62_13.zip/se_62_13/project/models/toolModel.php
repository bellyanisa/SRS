<?php 
    class Tool
    {
        public $serial,$tool_name,$type_name,$state_tool,$rightcopy,$num,$id_type;
        public function __construct($serial,$tool_name,$type_name,$state_tool,$rightcopy,$num,$id_type) 
        {
            $this->serial = $serial;
            $this->tool_name = $tool_name;
            $this->type_name = $type_name;
            $this->state_tool = $state_tool;
            $this->rightcopy = $rightcopy;
            $this->num = $num;
            $this->id_type = $id_type;
        }
        public static function search($key)
        {
   
            require("connection_connect.php");
            $sql = "SELECT tool.tname,type_tool.typeTool_name,tool.rightcopy,tool.state_tool,tool.id_type FROM tool INNER JOIN type_tool 
            WHERE tool.tname LIKE '%$key%' and tool.state_tool='ว่าง'
            and tool.id_type=type_tool.id_type";
            $result= $conn->query($sql);	
            while ($my_row = $result->fetch_assoc())	
            {	
                $serial= "555";
                $tool_name= $my_row['tname'];	
                $type_name = $my_row['typeTool_name'];
                $state_tool = $my_row['state_tool'];
                $rightcopy = $my_row['rightcopy'];
                $id_type = $my_row['id_type'];
                $toolList[]= new Tool($serial,$tool_name,$type_name,$state_tool,$rightcopy,null,$id_type);	   
            }
            require("connection_close.php");

            return $toolList;
        }
        public static function searchShow($key)
        {
   
            require("connection_connect.php");
            $sql = "SELECT tool.tname,type_tool.typeTool_name,tool.rightcopy,tool.state_tool,tool.id_type, COUNT(tname) as num FROM `tool` INNER JOIN type_tool 
            WHERE tool.id_type=type_tool.id_type
            GROUP BY tool.tname,type_tool.typeTool_name,tool.rightcopy,tool.state_tool,tool.id_type";
            $result= $conn->query($sql);	
            while ($my_row = $result->fetch_assoc())	
            {	
                $serial= "555";
                $tool_name= $my_row['tname'];	
                $type_name = $my_row['typeTool_name'];
                $state_tool = $my_row['state_tool'];
                $rightcopy = $my_row['rightcopy'];
                $num = $my_row['num'];
                $id_type = $my_row['id_type'];
                $toolList[] = new Tool($serial,$tool_name,$type_name,$state_tool,$rightcopy,$num,$id_type);	   
            }
            require("connection_close.php");

            return $toolList;
        }
        public static function get($serial)
        {
            require("connection_connect.php");
            $sql = "SELECT * FROM `tool` INNER JOIN type_tool
            where tool.id_type=type_tool.id_type";
            $result=$conn->query($sql);
            while($my_row = $result -> fetch_assoc())
            {
                if($serial==$my_row['serial_num']){
                    break;
                }
                    
            }               
            $serial= $my_row['serial_num'];		
            $tool_name = $my_row['tname'];
            $type_name = $my_row['typeTool_name'];
            $state_tool = $my_row['state_tool'];
            $rightcopy = $my_row['rightcopy'];
            $id_type = $my_row['id_type'];
            require("connection_close.php");
 
            return new Tool($serial,$tool_name,$type_name,$state_tool,$rightcopy,null,$id_type);
        }
        public static function getAll()
        {
            $toolList = [];
            require("connection_connect.php");
            $sql = "SELECT tool.tname,type_tool.typeTool_name,tool.rightcopy,tool.state_tool,tool.id_type, COUNT(tname) as num FROM `tool` INNER JOIN type_tool 
            WHERE tool.id_type=type_tool.id_type
            GROUP BY tool.tname,type_tool.typeTool_name,tool.rightcopy,tool.state_tool,tool.id_type";
            $result = $conn->query($sql);
            
            while ($my_row = $result->fetch_assoc()) 
            {
                $serial= "555";
                $tool_name= $my_row['tname'];	
                $type_name = $my_row['typeTool_name'];
                $state_tool = $my_row['state_tool'];
                $rightcopy = $my_row['rightcopy'];
                $num = $my_row['num'];
                $id_type = $my_row['id_type'];
                $toolList[] = new Tool($serial,$tool_name,$type_name,$state_tool,$rightcopy,$num,$id_type);
            }
            require("connection_close.php");
            return $toolList;
        }
       
        public static function getShow()
        {
            $toolList = [];
            require("connection_connect.php");
            $sql = "SELECT * From `tool` INNER JOIN type_tool WHERE tool.id_type=type_tool.id_type";
            $result = $conn->query($sql);
            
            while ($my_row = $result->fetch_assoc()) 
            {
                $serial= $my_row['serial_num'];
                $tool_name= $my_row['tname'];	
                $type_name = $my_row['typeTool_name'];
                $state_tool = $my_row['state_tool'];
                $rightcopy = $my_row['rightcopy'];
                $id_type = $my_row['id_type'];
                $toolList[] = new Tool($serial,$tool_name,$type_name,$state_tool,$rightcopy,null,$id_type);
            }
            require("connection_close.php");
            return $toolList;
        }
        
        public static function add($serial,$tool_name,$id_type,$rightcopy,$state_tool)
        {
            require("connection_connect.php");
            $sql = "INSERT into tool (serial_num,tname,id_type,rightcopy,state_tool) 
            values ('$serial','$tool_name','$id_type','$rightcopy','$state_tool')";
            $result= $conn->query($sql); 
            require("connection_close.php");
            return "add success $result rows"; 
        }
        public static function update($serial,$tool_name,$id_type,$rightcopy,$state_tool)
        {   
            require("connection_connect.php");
            $sql = "UPDATE tool SET serial_num = '$serial', tname = '$tool_name' , id_type = '$id_type' ,'rightcopy' = '$rightcopy','state_tool' = '$state_tool' 
            WHERE serial_num = '$serial' ";
            $result= $conn->query($sql);
            require("connection_close.php");
            return "update success $result row";     
        }
        public static function delete($serial)
        {   
            require_once("connection_connect.php");
            $sql = "DELETE from tool Where serial_num = '$serial'";
            $result= $conn->query($sql);
            require("connection_close.php");
            return "delete success $result row";     
        }
      
    
    }
?>
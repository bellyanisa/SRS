<?php 
    class Borrow
    {
        public $id_teacher,$teacher_name,$email_teacher;
        public function __construct($id_teacher,$teacher_name,$email_teacher) 
        {
            $this->id_teacher = $id_teacher;
            $this->teacher_name = $teacher_name;
            $this->email_teacher = $email_teacher;
            
        }
        public static function get($id_teacher)
        {
            require("connection_connect.php");
            $sql = "SELECT * FROM `teacher`";
            $result=$conn->query($sql);
            while($my_row = $result -> fetch_assoc())
            {
                if($id_teacher==$my_row['id_teacher']){
                    break;
                }
                    
            }               
            $id_teacher= $my_row['id_teacher'];		
            $teacher_name = $my_row['teacher_name'];
            $email_teacher = $my_row['email_teacher'];	
            require("connection_close.php");
 
            return new Teacher($id_teacher,$teacher_name,$email_teacher);
        }
        public static function getAll()
        {
            $teacherList = [];
            require("connection_connect.php");
            $sql = "SELECT * FROM `teacher` WHERE 1";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) 
            {
                $id_teacher= $my_row['id_teacher'];		
                $teacher_name = $my_row['teacher_name'];
                $email_teacher = $my_row['email_teacher'];		
                $teacherList[] = new Teacher($id_teacher,$teacher_name,$email_teacher);
            }
            require("connection_close.php");
            return $teacherList;
        }
        // public static function add($serial,$tool_name,$id_type,$rightcopy,$state_tool)
        // {
        //     require("connection_connect.php");
        //     $sql = "INSERT into tool (serial_num,tname,id_type,rightcopy,state_tool) 
        //     values ('$serial','$tool_name','$id_type','$rightcopy','$state_tool')";
        //     $result= $conn->query($sql); 
        //     require("connection_close.php");
        //     return "add success $result rows"; 
        // }
    
    }
?>